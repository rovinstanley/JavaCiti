package com.firstproject;

public class Main {

    public static void main(String[] args) {
	// write your code here
       String a1=AgeClassification(40);
       System.out.println(a1);

        String a2=AgeClassification(17);
        System.out.println(a2);

    }

    public static String AgeClassification (int age)
    {
        String classification = "";
           if (age>18 )
        {
            classification ="Adult";
        }
        else
        {
            classification = "Not Adult";
        }
        return classification;

        }


    }


